package net.mcreator.utility.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class DungeonGeneratorPart2Procedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, double numero_casuale_tipo_stanza) {
		boolean struttura_piazzata = false;
		double numero_casuale_quale_tipo_di_stanza = 0;
		numero_casuale_quale_tipo_di_stanza = numero_casuale_tipo_stanza;
		if (numero_casuale_quale_tipo_di_stanza < 835) {
			if (ControllasevuotoProcedure.execute(world, x, y, z, 9, 15, 15, 0, 0, "normal", "centrata")) {
				if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_hourglass_room_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 7, y - 1, z - 14), BlockPos.containing(x - 7, y - 1, z - 14),
									new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_hourglass_room_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 7, y - 1, z + 14), BlockPos.containing(x + 7, y - 1, z + 14),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_hourglass_room_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 14, y - 1, z - 7), BlockPos.containing(x + 14, y - 1, z - 7),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_hourglass_room_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 14, y - 1, z + 7), BlockPos.containing(x - 14, y - 1, z + 7),
									new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				}
				struttura_piazzata = true;
			}
		} else if (numero_casuale_quale_tipo_di_stanza < 845) {
			if (ControllasevuotoProcedure.execute(world, x, y, z, 5, 13, 11, 0, 0, "normal", "centrata")) {
				if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_stanza_degli_specchi"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 6, y - 1, z - 11), BlockPos.containing(x - 6, y - 1, z - 11),
									new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_stanza_degli_specchi"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 6, y - 1, z + 11), BlockPos.containing(x + 6, y - 1, z + 11),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_stanza_degli_specchi"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 11, y - 1, z - 6), BlockPos.containing(x + 11, y - 1, z - 6),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_stanza_degli_specchi"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 11, y - 1, z + 6), BlockPos.containing(x - 11, y - 1, z + 6),
									new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				}
				struttura_piazzata = true;
			}
		} else if (numero_casuale_quale_tipo_di_stanza < 905) {
			if (ControllasevuotoProcedure.execute(world, x, y, z, 7, 15, 14, 0, 0, "normal", "centrata")) {
				if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_lab_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 7, y - 1, z - 0), BlockPos.containing(x - 7, y - 1, z - 0),
									new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_lab_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 7, y - 1, z + 0), BlockPos.containing(x + 7, y - 1, z + 0),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_lab_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 0, y - 1, z - 7), BlockPos.containing(x + 0, y - 1, z - 7),
									new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_lab_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 0, y - 1, z + 7), BlockPos.containing(x - 0, y - 1, z + 7),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				}
				struttura_piazzata = true;
			}
		} else if (numero_casuale_quale_tipo_di_stanza < 950) {
			if (ControllasevuotoProcedure.execute(world, x, y, z, 5, 13, 13, 0, 0, "normal", "centrata")) {
				if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_nursey_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 6, y - 1, z - 0), BlockPos.containing(x - 6, y - 1, z - 0),
									new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_nursey_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 6, y - 1, z + 0), BlockPos.containing(x + 6, y - 1, z + 0),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_nursey_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 0, y - 1, z - 6), BlockPos.containing(x + 0, y - 1, z - 6),
									new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_strange_nursey_1"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 0, y - 1, z + 6), BlockPos.containing(x - 0, y - 1, z + 6),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				}
				struttura_piazzata = true;
			}
		} else if (numero_casuale_quale_tipo_di_stanza < 980) {
			if (ControllasevuotoProcedure.execute(world, x, y, z, 6, 11, 10, 0, 0, "normal", "centrata")) {
				if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_shard_room"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 5, y - 1, z - 0), BlockPos.containing(x - 5, y - 1, z - 0),
									new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_shard_room"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 5, y - 1, z + 0), BlockPos.containing(x + 5, y - 1, z + 0),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_shard_room"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x + 0, y - 1, z - 5), BlockPos.containing(x + 0, y - 1, z - 5),
									new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				} else {
					if (world instanceof ServerLevel _serverworld) {
						StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_shard_room"));
						if (template != null) {
							template.placeInWorld(_serverworld, BlockPos.containing(x - 0, y - 1, z + 5), BlockPos.containing(x - 0, y - 1, z + 5),
									new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
						}
					}
				}
				struttura_piazzata = true;
			}
		} else {
			if (numero_casuale_quale_tipo_di_stanza < 990) {
				if (ControllasevuotoProcedure.execute(world, x, y, z, 5, 13, 24, 0, 0, "normal", "centrata")) {
					if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_the_hollow_feast_1"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x - 6, y - 1, z - 0), BlockPos.containing(x - 6, y - 1, z - 0),
										new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_the_hollow_feast_1"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + 6, y - 1, z + 0), BlockPos.containing(x + 6, y - 1, z + 0),
										new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_the_hollow_feast_1"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + 0, y - 1, z - 6), BlockPos.containing(x + 0, y - 1, z - 6),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_the_hollow_feast_1"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x - 0, y - 1, z + 6), BlockPos.containing(x - 0, y - 1, z + 6),
										new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
					struttura_piazzata = true;
				}
			} else if (numero_casuale_quale_tipo_di_stanza <= 1000) {
				if (ControllasevuotoProcedure.execute(world, x, y, z, 6, 9, 10, 0, 0, "normal", "centrata")) {
					if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.NORTH) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_altar"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + 4, y - 1, z - 0), BlockPos.containing(x + 4, y - 1, z - 0),
										new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_180).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.SOUTH) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_altar"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x - 4, y - 1, z + 0), BlockPos.containing(x - 4, y - 1, z + 0),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((getBlockDirection(world, BlockPos.containing(x, y, z))) == Direction.EAST) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_altar"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + 0, y - 1, z + 4), BlockPos.containing(x + 0, y - 1, z + 4),
										new StructurePlaceSettings().setRotation(Rotation.COUNTERCLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(ResourceLocation.fromNamespaceAndPath("utility", "liminal_altar"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x - 0, y - 1, z - 4), BlockPos.containing(x - 0, y - 1, z - 4),
										new StructurePlaceSettings().setRotation(Rotation.CLOCKWISE_90).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
					struttura_piazzata = true;
				}
			}
		}
		return struttura_piazzata;
	}

	private static Direction getBlockDirection(LevelAccessor world, BlockPos pos) {
		BlockState blockState = world.getBlockState(pos);
		Property<?> property = blockState.getBlock().getStateDefinition().getProperty("facing");
		if (property != null && blockState.getValue(property) instanceof Direction direction)
			return direction;
		else if (blockState.hasProperty(BlockStateProperties.AXIS))
			return Direction.fromAxisAndDirection(blockState.getValue(BlockStateProperties.AXIS), Direction.AxisDirection.POSITIVE);
		else if (blockState.hasProperty(BlockStateProperties.HORIZONTAL_AXIS))
			return Direction.fromAxisAndDirection(blockState.getValue(BlockStateProperties.HORIZONTAL_AXIS), Direction.AxisDirection.POSITIVE);
		return Direction.NORTH;
	}
}