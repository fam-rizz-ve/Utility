/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utility.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.utility.UtilityMod;

public class UtilityModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, UtilityMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> UTILITYMAGIC = REGISTRY.register("utilitymagic",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.utility.utilitymagic")).icon(() -> new ItemStack(UtilityModItems.ENDKEY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(UtilityModItems.FLATKEY.get());
				tabData.accept(UtilityModItems.OVERWORDKEY.get());
				tabData.accept(UtilityModItems.NETHERKEY.get());
				tabData.accept(UtilityModItems.ENDKEY.get());
				tabData.accept(UtilityModItems.LIMBOKEY.get());
				tabData.accept(UtilityModItems.LIMBO_KEY_PART_1.get());
				tabData.accept(UtilityModItems.LIMINALY_KEY.get());
				tabData.accept(UtilityModItems.EMPTYKEY.get());
				tabData.accept(UtilityModItems.POWER_ESSENCE.get());
				tabData.accept(UtilityModItems.OVERWORLDESSENCE.get());
				tabData.accept(UtilityModItems.NEHTERESSENCE.get());
				tabData.accept(UtilityModItems.ENDESSECE.get());
				tabData.accept(UtilityModItems.FLATESSENCE.get());
				tabData.accept(UtilityModBlocks.ESSENCTIONDISTILIZER.get().asItem());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> UTILITY = REGISTRY.register("utility",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.utility.utility")).icon(() -> new ItemStack(UtilityModItems.NIGHTELMET_HELMET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(UtilityModItems.MEDIKIT.get());
				tabData.accept(UtilityModItems.BANDAGES.get());
				tabData.accept(UtilityModItems.TACTICALKNIFE.get());
				tabData.accept(UtilityModItems.IRONKNIFE.get());
				tabData.accept(UtilityModItems.KNIFEBLADE.get());
				tabData.accept(UtilityModItems.CREATIVENIGHTHELMET_HELMET.get());
				tabData.accept(UtilityModItems.EXPLOSIVESUIT_CHESTPLATE.get());
				tabData.accept(UtilityModItems.NIGHTELMET_HELMET.get());
				tabData.accept(UtilityModItems.NIGHTELMET_CHESTPLATE.get());
				tabData.accept(UtilityModItems.NIGHTELMET_LEGGINGS.get());
				tabData.accept(UtilityModItems.NIGHTELMET_BOOTS.get());
				tabData.accept(UtilityModItems.TACTICAL_TEMPLATE.get());
				tabData.accept(UtilityModItems.CREATIVEDESPWANWAND.get());
				tabData.accept(UtilityModItems.CREATIVE_NIGHT_VISION_GOGGLES.get());
				tabData.accept(UtilityModItems.SURVIVAL_NIGHT_VISION_GOGGLES_ITEM.get());
				tabData.accept(UtilityModItems.LENTI_SURVIVAL_NIGHT_VISION_GOGGLES.get());
				tabData.accept(UtilityModItems.BUILDING_TOOL.get());
				tabData.accept(UtilityModItems.LENTE.get());
				tabData.accept(UtilityModItems.OCCHIALI.get());
				tabData.accept(UtilityModItems.OMNI_WANDS.get());
			}).withTabsBefore(UTILITYMAGIC.getId()).build());
}