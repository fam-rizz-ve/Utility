/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utility.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.utility.item.WearableglassItem;
import net.mcreator.utility.item.TacticalknifeItem;
import net.mcreator.utility.item.TacticalTemplateItem;
import net.mcreator.utility.item.PowerEssenceItem;
import net.mcreator.utility.item.OverworldessenceItem;
import net.mcreator.utility.item.OverwordkeyItem;
import net.mcreator.utility.item.NightelmetItem;
import net.mcreator.utility.item.NetherkeyItem;
import net.mcreator.utility.item.NehteressenceItem;
import net.mcreator.utility.item.MedikitItem;
import net.mcreator.utility.item.LiminalyKeyItem;
import net.mcreator.utility.item.LimbokeyItem;
import net.mcreator.utility.item.LimboKeyPart1Item;
import net.mcreator.utility.item.KnifebladeItem;
import net.mcreator.utility.item.IronknifeItem;
import net.mcreator.utility.item.FlatkeyItem;
import net.mcreator.utility.item.FlatessenceItem;
import net.mcreator.utility.item.ExplosivesuitItem;
import net.mcreator.utility.item.EndkeyItem;
import net.mcreator.utility.item.EndesseceItem;
import net.mcreator.utility.item.EmptykeyItem;
import net.mcreator.utility.item.CreativenighthelmetItem;
import net.mcreator.utility.item.BlastCellItem;
import net.mcreator.utility.item.BandagesItem;
import net.mcreator.utility.UtilityMod;

public class UtilityModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(UtilityMod.MODID);
	public static final DeferredItem<Item> FLATKEY = REGISTRY.register("flatkey", FlatkeyItem::new);
	public static final DeferredItem<Item> OVERWORDKEY = REGISTRY.register("overwordkey", OverwordkeyItem::new);
	public static final DeferredItem<Item> NETHERKEY = REGISTRY.register("netherkey", NetherkeyItem::new);
	public static final DeferredItem<Item> ENDKEY = REGISTRY.register("endkey", EndkeyItem::new);
	public static final DeferredItem<Item> LIMBOKEY = REGISTRY.register("limbokey", LimbokeyItem::new);
	public static final DeferredItem<Item> LIMBO_KEY_PART_1 = REGISTRY.register("limbo_key_part_1", LimboKeyPart1Item::new);
	public static final DeferredItem<Item> LIMINALY_KEY = REGISTRY.register("liminaly_key", LiminalyKeyItem::new);
	public static final DeferredItem<Item> EMPTYKEY = REGISTRY.register("emptykey", EmptykeyItem::new);
	public static final DeferredItem<Item> WEARABLEGLASS = REGISTRY.register("wearableglass", WearableglassItem::new);
	public static final DeferredItem<Item> MEDIKIT = REGISTRY.register("medikit", MedikitItem::new);
	public static final DeferredItem<Item> BANDAGES = REGISTRY.register("bandages", BandagesItem::new);
	public static final DeferredItem<Item> TACTICALKNIFE = REGISTRY.register("tacticalknife", TacticalknifeItem::new);
	public static final DeferredItem<Item> IRONKNIFE = REGISTRY.register("ironknife", IronknifeItem::new);
	public static final DeferredItem<Item> KNIFEBLADE = REGISTRY.register("knifeblade", KnifebladeItem::new);
	public static final DeferredItem<Item> CREATIVENIGHTHELMET_HELMET = REGISTRY.register("creativenighthelmet_helmet", CreativenighthelmetItem.Helmet::new);
	public static final DeferredItem<Item> EXPLOSIVESUIT_CHESTPLATE = REGISTRY.register("explosivesuit_chestplate", ExplosivesuitItem.Chestplate::new);
	public static final DeferredItem<Item> BLAST_CELL = REGISTRY.register("blast_cell", BlastCellItem::new);
	public static final DeferredItem<Item> NIGHTELMET_HELMET = REGISTRY.register("nightelmet_helmet", NightelmetItem.Helmet::new);
	public static final DeferredItem<Item> NIGHTELMET_CHESTPLATE = REGISTRY.register("nightelmet_chestplate", NightelmetItem.Chestplate::new);
	public static final DeferredItem<Item> NIGHTELMET_LEGGINGS = REGISTRY.register("nightelmet_leggings", NightelmetItem.Leggings::new);
	public static final DeferredItem<Item> NIGHTELMET_BOOTS = REGISTRY.register("nightelmet_boots", NightelmetItem.Boots::new);
	public static final DeferredItem<Item> TACTICAL_TEMPLATE = REGISTRY.register("tactical_template", TacticalTemplateItem::new);
	public static final DeferredItem<Item> POWER_ESSENCE = REGISTRY.register("power_essence", PowerEssenceItem::new);
	public static final DeferredItem<Item> OVERWORLDESSENCE = REGISTRY.register("overworldessence", OverworldessenceItem::new);
	public static final DeferredItem<Item> NEHTERESSENCE = REGISTRY.register("nehteressence", NehteressenceItem::new);
	public static final DeferredItem<Item> ENDESSECE = REGISTRY.register("endessece", EndesseceItem::new);
	public static final DeferredItem<Item> FLATESSENCE = REGISTRY.register("flatessence", FlatessenceItem::new);
	public static final DeferredItem<Item> ESSENCTIONDISTILIZER = block(UtilityModBlocks.ESSENCTIONDISTILIZER);
	public static final DeferredItem<Item> DUNGEONGENERATORBLOCK = block(UtilityModBlocks.DUNGEONGENERATORBLOCK);
	public static final DeferredItem<Item> FADED_CONCRETE = block(UtilityModBlocks.FADED_CONCRETE);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}